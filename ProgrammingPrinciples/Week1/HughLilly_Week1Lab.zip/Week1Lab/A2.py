
# Use 1 variable of integer type and another variable of string type.
# Show their output together.

number = 50
quote = "This is a string. This is an integer cast to a string: "

print(quote + str(number))

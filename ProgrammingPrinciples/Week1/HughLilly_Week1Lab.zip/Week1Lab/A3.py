
# Take three inputs from users, store them in three different variables.
# Make sure the user only enters integers.
# Calculate the average and show to user.

first_num = int(input("Enter a number: "))
second_num = int(input("Enter another number: "))

average = (first_num / second_num)

print("The average is " + str(average))

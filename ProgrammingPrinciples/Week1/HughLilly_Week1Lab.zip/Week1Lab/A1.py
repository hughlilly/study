
# Add two values in two variables. Store their sum, subtraction, multiplication,
# and division into four different variables and print the output.

first_num = 20
second_num = 10

sum_of_nums = first_num + second_num
subtraction_of_nums = first_num - second_num
multiplication_of_nums = first_num * second_num
division_of_nums = first_num / second_num

print("Sum is " + sum_of_nums)
print("Subtraction is " + subtraction_of_nums)
print("Multiplication is " + multiplication_of_nums)
print("Division is " + division_of_nums)
